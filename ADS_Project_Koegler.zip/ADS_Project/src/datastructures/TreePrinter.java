package datastructures;

public class TreePrinter extends TreeAction{
		public void run(Tree.TreeNode n) {
			System.out.println(n.toString());
		}
	}