package datastructures;

public abstract class TreeAction
	{
		public abstract void run(Tree.TreeNode n);
	}